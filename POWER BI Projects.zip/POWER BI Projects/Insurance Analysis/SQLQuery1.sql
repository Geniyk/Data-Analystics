
Create Database Insurancedb



select * from [dbo].[InsuranceData]