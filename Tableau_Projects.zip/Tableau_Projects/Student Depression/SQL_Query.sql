
create database Depression

use Depression

select * from [dbo].[Depression Student Dataset]

---- Gender
select Gender,count(*) from [dbo].[Depression Student Dataset]
group by Gender;

update [dbo].[Depression Student Dataset]
set Gender='F' where Gender='Female'

update [dbo].[Depression Student Dataset]
set Gender='M' where Gender='Male'

Select * from [dbo].[Depression Student Dataset]
where Gender is null

Select * from [dbo].[Depression Student Dataset]
where Gender=''

---- Age
select Age,count(*) as [Age Count] from [dbo].[Depression Student Dataset]
group by age
order by age desc

alter table [dbo].[Depression Student Dataset]
add Age_Group varchar(max)

select * from [dbo].[Depression Student Dataset]

update [dbo].[Depression Student Dataset]
set age_group=
case when age between 18 and 24 then 'A1'
Else case when age between 25 and 30 then 'A2'
else 'A3' end end 

select age_group,count(*) from[dbo].[Depression Student Dataset]
group by age_group

--------------ALL COLUMNS NAME
Select * from INFORMATION_SCHEMA.columns where table_name
like 'Depression Student Dataset'

------Academic_Pressure---
select Academic_Pressure,count(*) from[dbo].[Depression Student Dataset]
group by Academic_Pressure

----Study_Satisfaction----
select Study_Satisfaction,count(*) from[dbo].[Depression Student Dataset]
group by Study_Satisfaction

------Sleep_Duration----
select Sleep_Duration,count(*) from[dbo].[Depression Student Dataset]
group by Sleep_Duration

-------Dietary_Habits-----
select Dietary_Habits, count(*) from[dbo].[Depression Student Dataset]
group by Dietary_Habits

------Have_you_ever_had_suicidal_thoughts-----
select Have_you_ever_had_suicidal_thoughts, count(*) from[dbo].[Depression Student Dataset]
group by Have_you_ever_had_suicidal_thoughts

------Study_Hours---
select Study_Hours, count(*) from[dbo].[Depression Student Dataset]
group by Study_Hours

-------Financial_Stress-----
select Financial_Stress,count(*) from[dbo].[Depression Student Dataset]
group by Financial_Stress

----Family_History_of_Mental_Illness-----
select Family_History_of_Mental_Illness,count(*) from[dbo].[Depression Student Dataset]
group by Family_History_of_Mental_Illness

------Depression----
select Depression,count(*) from[dbo].[Depression Student Dataset]
group by Depression

----Age_Group---
select Age_Group,count(*) from[dbo].[Depression Student Dataset]
group by Age_Group

---Identity Column
select * from [Depression Student Dataset]

alter table [Depression Student Dataset]
add Index_Column int identity(1,1)

update [Depression Student Dataset]
set Depression='No' where  Depression=0

Select * from INFORMATION_SCHEMA.columns where table_name
like 'Depression Student Dataset'

---Changing Datatype
Alter Table [Depression Student Dataset]
Alter column Depression varchar(Max)

update [Depression Student Dataset]
set Depression='Yes' where  Depression='1'

Select * from [Depression Student Dataset]

SELECT Depression, count(*) FROM [Depression Student Dataset]
group by Depression






















